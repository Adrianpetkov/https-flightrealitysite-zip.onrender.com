from flask import Flask, request, send_from_directory, render_template_string
import os

app = Flask(__name__)
UPLOAD_FOLDER = 'videos'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

@app.route('/')
def index():
    video_files = os.listdir(UPLOAD_FOLDER)
    video_blocks = ''.join([
        f"""
        <div style='margin-bottom: 30px;'>
            <h4>{v}</h4>
            <video width='480' controls>
                <source src='/videos/{v}' type='video/mp4'>
                Your browser does not support the video tag.
            </video>
        </div>
        """ for v in video_files
    ])

    html_content = f"""
    <html lang="bg">
    <head><meta charset="utf-8"><title>FlightReality</title></head>
    <body style="font-family: Arial, sans-serif; text-align: center; padding: 40px; background-color: #e6f0ff;">
    <h1 style="color: #003366;">✈️ FlightReality – Качи видео клип</h1>
    <form action="/upload" method="POST" enctype="multipart/form-data">
      <input type="file" name="video" accept="video/*" required>
      <button type="submit">📤 Качи</button>
    </form>
    <h2 style="margin-top: 40px;">🎥 Гледай качени видеа:</h2>
    {video_blocks}
    </body>
    </html>
    """
    return render_template_string(html_content)

@app.route('/upload', methods=['POST'])
def upload():
    video = request.files.get('video')
    if video:
        video.save(os.path.join(UPLOAD_FOLDER, video.filename))
        return f"✅ Успешно качено: {video.filename}<br><br><a href='/'>⬅ Обратно</a>"
    return "❌ Няма избран файл"

@app.route('/videos/<filename>')
def serve_video(filename):
    return send_from_directory(UPLOAD_FOLDER, filename)

if __name__ == '__main__':
    app.run(debug=True)
